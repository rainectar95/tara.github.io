# Modal Bottom Sheet in pure CSS | Material Design

A Pen created on CodePen.io. Original URL: [https://codepen.io/Raine-Nectar/pen/GRaZYVM](https://codepen.io/Raine-Nectar/pen/GRaZYVM).

This is an animated modal bottom sheet based on Google's Material Design standards. It's responsive and works without JavaScript! JavaScript could easily be added to enhance it, however. Within the bottom sheet, you'll find a social share icon grid.